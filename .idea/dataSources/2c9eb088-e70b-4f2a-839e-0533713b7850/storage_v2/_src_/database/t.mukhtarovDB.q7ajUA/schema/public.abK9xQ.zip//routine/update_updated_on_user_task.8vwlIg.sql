create function update_updated_on_user_task() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

alter function update_updated_on_user_task() owner to postgres;

